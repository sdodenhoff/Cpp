//
//  degree.h
//  PA_C867_Dodenhoff
//
//  Created by Samantha Dodenhoff on 3/12/23.
//

#ifndef degree_h
#define degree_h
#include <iostream>
#include <stdio.h>
using namespace std;

enum class DegreeProgram {SECURITY, NETWORK, SOFTWARE};
static const string degreeProgramString[] = {"SECURITY", "NETWORK", "SOFTWARE"};


#endif









